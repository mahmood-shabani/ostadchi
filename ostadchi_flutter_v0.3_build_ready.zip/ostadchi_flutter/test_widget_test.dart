import 'package:flutter_test/flutter_test.dart';
import 'package:ostadchi/app/app.dart';

void main() {
  testWidgets('Ostadchi home renders', (tester) async {
    await tester.pumpWidget(const OstadchiApp());
    expect(find.text('استادچی'), findsWidgets);
    expect(find.text('خدمات موردنیازت را پیدا کن'), findsOneWidget);
  });
}
