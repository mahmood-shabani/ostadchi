# استادچی — Flutter v0.3 Build Ready

این نسخه برای Build ابری اندروید آماده شده و ساختار Flutter، Supabase و Codemagic را دارد.

## وضعیت
- Flutter app source
- Android Gradle project
- Supabase OTP integration
- PostgreSQL migration + RLS
- RTL Persian UI
- Codemagic workflow
- Basic widget test

## Supabase
فایل migration:
`supabase/migrations/202609260001_initial_schema.sql`

در Supabase باید Phone Authentication و یک SMS provider واقعی تنظیم شود.

## Local build
```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

## Codemagic
در Codemagic، متغیرهای امن `SUPABASE_URL` و `SUPABASE_ANON_KEY` را بساز و workflow موجود در `codemagic.yaml` را اجرا کن.

این پروژه از کلید `anon` استفاده می‌کند؛ هرگز `service_role` را داخل اپ Flutter قرار نده.

## محدودیت فعلی
Build واقعی در این محیط اجرا نشده چون Flutter SDK در محیط فعلی موجود نیست. بنابراین قبل از انتشار، Codemagic باید `flutter analyze`, `flutter test` و `flutter build apk` را اجرا و نتیجه موفق را تأیید کند.
