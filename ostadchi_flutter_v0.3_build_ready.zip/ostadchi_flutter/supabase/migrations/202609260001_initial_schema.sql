-- Ostadchi v0.2 database schema for Supabase/Postgres.
-- Auth users are stored by Supabase in auth.users. Public profile data lives here.

create extension if not exists pgcrypto;

create table if not exists public.cities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  province text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  display_name text,
  selected_city_id uuid references public.cities(id) on delete set null,
  avatar_url text,
  is_worker boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  icon_key text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on delete restrict,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(category_id, name)
);

create table if not exists public.worker_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  profession text not null,
  bio text,
  experience_years integer not null default 0 check (experience_years >= 0),
  base_price numeric(14,2),
  identity_verified boolean not null default false,
  documents_verified boolean not null default false,
  field_verified boolean not null default false,
  field_verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.worker_cities (
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  city_id uuid not null references public.cities(id) on delete restrict,
  primary key(worker_id, city_id)
);

create table if not exists public.worker_services (
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  primary key(worker_id, service_id)
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete cascade,
  city_id uuid not null references public.cities(id) on delete restrict,
  title text not null,
  description text not null,
  budget_min numeric(14,2),
  budget_max numeric(14,2),
  status text not null default 'open' check (status in ('draft','open','assigned','in_progress','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.proposals (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  price numeric(14,2) not null,
  estimated_days integer check (estimated_days is null or estimated_days > 0),
  message text,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','withdrawn')),
  created_at timestamptz not null default now(),
  unique(project_id, worker_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null unique references public.projects(id) on delete cascade,
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  customer_id uuid not null references public.profiles(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.verifications (
  id uuid primary key default gen_random_uuid(),
  worker_id uuid not null references public.worker_profiles(id) on delete cascade,
  verification_type text not null check (verification_type in ('identity','documents','field')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  verified_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_city on public.profiles(selected_city_id);
create index if not exists idx_worker_cities_city on public.worker_cities(city_id);
create index if not exists idx_worker_services_service on public.worker_services(service_id);
create index if not exists idx_projects_city_status on public.projects(city_id, status);
create index if not exists idx_proposals_project on public.proposals(project_id);
create index if not exists idx_reviews_worker on public.reviews(worker_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, phone)
  values (new.id, new.phone)
  on conflict (id) do update set phone = excluded.phone, updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles for each row execute procedure public.set_updated_at();
drop trigger if exists worker_profiles_updated_at on public.worker_profiles;
create trigger worker_profiles_updated_at before update on public.worker_profiles for each row execute procedure public.set_updated_at();
drop trigger if exists projects_updated_at on public.projects;
create trigger projects_updated_at before update on public.projects for each row execute procedure public.set_updated_at();

alter table public.cities enable row level security;
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.services enable row level security;
alter table public.worker_profiles enable row level security;
alter table public.worker_cities enable row level security;
alter table public.worker_services enable row level security;
alter table public.projects enable row level security;
alter table public.proposals enable row level security;
alter table public.reviews enable row level security;
alter table public.verifications enable row level security;

create policy "cities readable by authenticated users" on public.cities for select to authenticated using (is_active = true);
create policy "categories readable by authenticated users" on public.categories for select to authenticated using (is_active = true);
create policy "services readable by authenticated users" on public.services for select to authenticated using (is_active = true);

create policy "profile owner can read" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profile owner can update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "workers readable by authenticated users" on public.worker_profiles for select to authenticated using (true);
create policy "worker owner can insert" on public.worker_profiles for insert to authenticated with check (user_id = auth.uid());
create policy "worker owner can update" on public.worker_profiles for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "worker cities readable" on public.worker_cities for select to authenticated using (true);
create policy "worker services readable" on public.worker_services for select to authenticated using (true);

create policy "project owner can read" on public.projects for select to authenticated using (customer_id = auth.uid());
create policy "authenticated users can create projects" on public.projects for insert to authenticated with check (customer_id = auth.uid());
create policy "project owner can update" on public.projects for update to authenticated using (customer_id = auth.uid()) with check (customer_id = auth.uid());

create policy "proposal worker or project owner can read" on public.proposals for select to authenticated using (
  worker_id in (select id from public.worker_profiles where user_id = auth.uid())
  or project_id in (select id from public.projects where customer_id = auth.uid())
);
create policy "worker can create proposal" on public.proposals for insert to authenticated with check (
  worker_id in (select id from public.worker_profiles where user_id = auth.uid())
);

create policy "reviews readable" on public.reviews for select to authenticated using (true);
create policy "customer can create review" on public.reviews for insert to authenticated with check (customer_id = auth.uid());

create policy "verification owner can read" on public.verifications for select to authenticated using (
  worker_id in (select id from public.worker_profiles where user_id = auth.uid())
);

insert into public.cities (name, province) values
('آبادان','خوزستان'), ('اهواز','خوزستان'), ('خرمشهر','خوزستان'), ('تهران','تهران')
on conflict (name) do nothing;

insert into public.categories (name, icon_key) values
('ساختمان','construction'), ('خودرو و موتورسیکلت','directions_car'), ('جوشکاری','build'), ('تأسیسات','plumbing')
on conflict (name) do nothing;
