import 'package:flutter/material.dart';
import '../../data/models/worker.dart';

class WorkerCard extends StatelessWidget {
  const WorkerCard({super.key, required this.worker, required this.onTap});

  final Worker worker;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                child: Text(worker.name.characters.first),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Flexible(child: Text(worker.name, style: const TextStyle(fontWeight: FontWeight.bold))),
                      if (worker.fieldVerified) ...[
                        const SizedBox(width: 6),
                        const Icon(Icons.verified, size: 18),
                      ],
                    ]),
                    const SizedBox(height: 4),
                    Text(worker.profession),
                    const SizedBox(height: 5),
                    Text('★ ${worker.rating}  •  ${worker.reviewCount} نظر  •  ${worker.experienceYears} سال تجربه'),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ],
          ),
        ),
      ),
    );
  }
}
