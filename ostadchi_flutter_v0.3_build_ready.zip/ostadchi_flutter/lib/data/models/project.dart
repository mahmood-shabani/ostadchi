class Project {
  const Project({
    required this.title,
    required this.description,
    required this.city,
    required this.budget,
  });

  final String title;
  final String description;
  final String city;
  final int budget;
}
