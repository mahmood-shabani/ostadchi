class Worker {
  const Worker({
    required this.id,
    required this.name,
    required this.profession,
    required this.city,
    required this.experienceYears,
    required this.rating,
    required this.reviewCount,
    required this.services,
    this.identityVerified = false,
    this.fieldVerified = false,
  });

  final String id;
  final String name;
  final String profession;
  final String city;
  final int experienceYears;
  final double rating;
  final int reviewCount;
  final List<String> services;
  final bool identityVerified;
  final bool fieldVerified;
}
