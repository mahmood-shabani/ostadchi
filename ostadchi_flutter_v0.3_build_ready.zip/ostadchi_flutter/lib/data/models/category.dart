class ServiceCategory {
  const ServiceCategory({required this.name, required this.icon});
  final String name;
  final String icon;
}
