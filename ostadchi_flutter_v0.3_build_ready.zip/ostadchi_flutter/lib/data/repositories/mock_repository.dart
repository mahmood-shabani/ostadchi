import '../models/category.dart';
import '../models/worker.dart';

class MockRepository {
  static const categories = <ServiceCategory>[
    ServiceCategory(name: 'ساختمان', icon: '🏗️'),
    ServiceCategory(name: 'خودرو و موتورسیکلت', icon: '🏍️'),
    ServiceCategory(name: 'تأسیسات', icon: '🔧'),
    ServiceCategory(name: 'جوشکاری', icon: '⚙️'),
    ServiceCategory(name: 'برق', icon: '⚡'),
    ServiceCategory(name: 'نجاری', icon: '🪚'),
  ];

  static const workers = <Worker>[
    Worker(
      id: 'w1', name: 'علی رضایی', profession: 'کاشی‌کار', city: 'آبادان',
      experienceYears: 12, rating: 4.8, reviewCount: 41,
      services: ['کاشی‌کاری', 'سرامیک', 'بازسازی'], identityVerified: true, fieldVerified: true,
    ),
    Worker(
      id: 'w2', name: 'رضا کریمی', profession: 'کاشی‌کار', city: 'آبادان',
      experienceYears: 8, rating: 4.6, reviewCount: 27,
      services: ['کاشی‌کاری', 'سنگ‌کاری'], identityVerified: true,
    ),
    Worker(
      id: 'w3', name: 'حسن احمدی', profession: 'مکانیک موتورسیکلت', city: 'آبادان',
      experienceYears: 10, rating: 4.9, reviewCount: 63,
      services: ['تعمیر موتور', 'تراش و سیلندر', 'برق موتورسیکلت'], identityVerified: true, fieldVerified: true,
    ),
  ];
}
