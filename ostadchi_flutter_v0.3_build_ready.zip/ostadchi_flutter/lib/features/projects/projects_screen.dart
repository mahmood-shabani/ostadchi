import 'package:flutter/material.dart';
import '../../data/models/project.dart';

class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});
  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  final List<Project> _projects = [];

  Future<void> _addProject() async {
    final title = TextEditingController();
    final description = TextEditingController();
    final budget = TextEditingController();
    final result = await showDialog<Project>(context: context, builder: (context) => AlertDialog(title: const Text('ثبت پروژه'), content: SingleChildScrollView(child: Column(children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان پروژه')), const SizedBox(height: 10), TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیحات')), const SizedBox(height: 10), TextField(controller: budget, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'بودجه تقریبی'))])), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')), FilledButton(onPressed: () { if (title.text.trim().isEmpty) return; Navigator.pop(context, Project(title: title.text.trim(), description: description.text.trim(), city: 'آبادان', budget: int.tryParse(budget.text) ?? 0)); }, child: const Text('ثبت'))]));
    title.dispose(); description.dispose(); budget.dispose();
    if (result == null || !mounted) return;
    setState(() => _projects.add(result));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: _projects.isEmpty ? const Center(child: Text('هنوز پروژه‌ای ثبت نکرده‌اید.')) : ListView(padding: const EdgeInsets.all(16), children: _projects.map((p) => Card(child: ListTile(title: Text(p.title), subtitle: Text(p.description), trailing: Text(p.budget == 0 ? 'توافقی' : '${p.budget} تومان')))).toList()), floatingActionButton: FloatingActionButton.extended(onPressed: _addProject, icon: const Icon(Icons.add), label: const Text('ثبت پروژه')));
  }
}
