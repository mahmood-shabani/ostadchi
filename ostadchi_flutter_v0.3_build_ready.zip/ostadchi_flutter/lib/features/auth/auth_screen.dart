import 'package:flutter/material.dart';

import '../../data/services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.authService});

  final AuthService authService;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  bool _otpSent = false;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  String _normalizePhone(String raw) {
    var phone = raw.trim().replaceAll(' ', '').replaceAll('-', '');
    if (phone.startsWith('00')) phone = '+${phone.substring(2)}';
    if (phone.startsWith('09')) phone = '+98${phone.substring(1)}';
    return phone;
  }

  Future<void> _sendOtp() async {
    final phone = _normalizePhone(_phoneController.text);
    if (!RegExp(r'^\+[1-9]\d{7,14}$').hasMatch(phone)) {
      setState(() => _error = 'شماره موبایل را با فرمت صحیح وارد کنید؛ مثال: 09121234567');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await widget.authService.sendOtp(phone);
      if (!mounted) return;
      setState(() => _otpSent = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('کد تأیید ارسال شد.')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = _friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _verifyOtp() async {
    final phone = _normalizePhone(_phoneController.text);
    final token = _otpController.text.trim();
    if (token.length != 6) {
      setState(() => _error = 'کد تأیید باید ۶ رقم باشد.');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await widget.authService.verifyOtp(phone: phone, token: token);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = _friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _friendlyError(Object error) {
    final message = error.toString();
    if (message.contains('Invalid login credentials')) return 'کد تأیید اشتباه است.';
    if (message.contains('rate limit')) return 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره امتحان کنید.';
    return 'خطا در ارتباط با سرویس احراز هویت. تنظیمات OTP را بررسی کنید.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.handyman_outlined, size: 72),
                  const SizedBox(height: 16),
                  const Text(
                    'استادچی',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _otpSent ? 'کد پیامک‌شده را وارد کنید' : 'برای شروع، شماره موبایل خود را وارد کنید',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    enabled: !_otpSent && !_loading,
                    decoration: const InputDecoration(
                      labelText: 'شماره موبایل',
                      hintText: '09121234567',
                      prefixIcon: Icon(Icons.phone_android),
                    ),
                  ),
                  if (_otpSent) ...[
                    const SizedBox(height: 16),
                    TextField(
                      controller: _otpController,
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'کد تأیید',
                        prefixIcon: Icon(Icons.verified_outlined),
                        counterText: '',
                      ),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: _loading ? null : (_otpSent ? _verifyOtp : _sendOtp),
                    child: _loading
                        ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(_otpSent ? 'تأیید و ورود' : 'ارسال کد تأیید'),
                  ),
                  if (_otpSent) ...[
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: _loading ? null : () => setState(() => _otpSent = false),
                      child: const Text('تغییر شماره موبایل'),
                    ),
                  ],
                  const SizedBox(height: 24),
                  const Text(
                    'با ورود، حساب کاربری شما ساخته یا بازیابی می‌شود. در این نسخه رمز عبور جداگانه نداریم.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
