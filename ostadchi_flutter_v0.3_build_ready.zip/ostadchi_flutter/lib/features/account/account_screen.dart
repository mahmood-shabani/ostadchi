import 'package:flutter/material.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 36)),
      const SizedBox(height: 12),
      const Center(child: Text('حساب من', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      const SizedBox(height: 20),
      Card(child: ListTile(leading: const Icon(Icons.handyman_outlined), title: const Text('فعال‌سازی پروفایل استادکار'), subtitle: const Text('برای ارائه خدمات و دریافت پروژه'))),
      Card(child: ListTile(leading: const Icon(Icons.location_on_outlined), title: const Text('شهرهای فعالیت'), subtitle: const Text('در نسخه بعد امکان انتخاب چند شهر اضافه می‌شود'))),
      Card(child: ListTile(leading: const Icon(Icons.verified_user_outlined), title: const Text('احراز هویت و مدارک'), subtitle: const Text('مدیریت وضعیت تأیید حساب'))),
      Card(child: ListTile(leading: const Icon(Icons.support_agent), title: const Text('پشتیبانی و گزارش تخلف'), subtitle: const Text('ثبت درخواست پشتیبانی'))),
    ]);
  }
}
