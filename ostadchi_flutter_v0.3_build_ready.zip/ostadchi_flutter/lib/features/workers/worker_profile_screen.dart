import 'package:flutter/material.dart';
import '../../data/models/worker.dart';

class WorkerProfileScreen extends StatelessWidget {
  const WorkerProfileScreen({super.key, required this.worker});
  final Worker worker;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل استادکار')),
      bottomNavigationBar: SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: FilledButton.icon(onPressed: () => _request(context), icon: const Icon(Icons.send), label: const Text('درخواست همکاری')))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        CircleAvatar(radius: 42, child: Text(worker.name.characters.first, style: const TextStyle(fontSize: 28))),
        const SizedBox(height: 10),
        Center(child: Text(worker.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold))),
        Center(child: Text(worker.profession)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
          Chip(label: Text('★ ${worker.rating}')),
          Chip(label: Text('${worker.reviewCount} نظر')),
          Chip(label: Text('${worker.experienceYears} سال تجربه')),
          if (worker.identityVerified) const Chip(avatar: Icon(Icons.verified_user, size: 18), label: Text('هویت تأییدشده')),
          if (worker.fieldVerified) const Chip(avatar: Icon(Icons.verified, size: 18), label: Text('تأیید میدانی')),
        ]),
        const SizedBox(height: 24),
        const Text('خدمات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...worker.services.map((s) => ListTile(leading: const Icon(Icons.check_circle_outline), title: Text(s), contentPadding: EdgeInsets.zero)),
        const Divider(height: 28),
        const Text('پروژه‌ها و نمونه‌کارها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Card(child: ListTile(leading: Icon(Icons.photo_library_outlined), title: Text('نمونه‌کارها'), subtitle: Text('در نسخه بعدی گالری واقعی پروژه اضافه می‌شود.'))),
      ]),
    );
  }

  void _request(BuildContext context) {
    showDialog<void>(context: context, builder: (_) => AlertDialog(title: const Text('درخواست همکاری'), content: const Text('در نسخه فعلی این درخواست شبیه‌سازی می‌شود. در نسخه بعد به پروژه، پیشنهاد قیمت و قرارداد متصل خواهد شد.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))]));
  }
}
