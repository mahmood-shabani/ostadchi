import 'package:flutter/material.dart';
import '../../core/widgets/worker_card.dart';
import '../../data/repositories/mock_repository.dart';
import 'worker_profile_screen.dart';

class WorkerListScreen extends StatefulWidget {
  const WorkerListScreen({super.key});
  @override
  State<WorkerListScreen> createState() => _WorkerListScreenState();
}

class _WorkerListScreenState extends State<WorkerListScreen> {
  String query = '';
  bool verifiedOnly = false;

  @override
  Widget build(BuildContext context) {
    final workers = MockRepository.workers.where((w) {
      final q = query.trim();
      final matches = q.isEmpty || w.name.contains(q) || w.profession.contains(q) || w.services.any((s) => s.contains(q));
      return matches && (!verifiedOnly || w.fieldVerified);
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('جستجوی استادکار')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(onChanged: (v) => setState(() => query = v), autofocus: true, decoration: const InputDecoration(hintText: 'نام، تخصص یا خدمت', prefixIcon: Icon(Icons.search))),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('فقط استادکاران تأییدشده'), value: verifiedOnly, onChanged: (v) => setState(() => verifiedOnly = v)),
        const SizedBox(height: 8),
        if (workers.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('موردی پیدا نشد.'))),
        ...workers.map((w) => Padding(padding: const EdgeInsets.only(bottom: 10), child: WorkerCard(worker: w, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkerProfileScreen(worker: w)))))).toList(),
      ]),
    );
  }
}
