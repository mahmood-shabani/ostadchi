import 'package:flutter/material.dart';
import '../../core/widgets/worker_card.dart';
import '../../data/repositories/mock_repository.dart';
import '../workers/worker_profile_screen.dart';
import '../workers/worker_list_screen.dart';
import '../categories/category_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.city});
  final String city;

  @override
  Widget build(BuildContext context) {
    final workers = MockRepository.workers.where((w) => w.city == city).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('خدمات موردنیازت را پیدا کن', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          readOnly: true,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WorkerListScreen())),
          decoration: const InputDecoration(hintText: 'جستجوی استادکار، تخصص یا خدمت', prefixIcon: Icon(Icons.search)),
        ),
        const SizedBox(height: 20),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('دسته‌بندی‌ها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          TextButton(onPressed: () {}, child: const Text('همه')),
        ]),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: MockRepository.categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 1.15, crossAxisSpacing: 8, mainAxisSpacing: 8),
          itemBuilder: (context, index) {
            final category = MockRepository.categories[index];
            return Card(child: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryScreen(category: category))), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(category.icon, style: const TextStyle(fontSize: 28)), const SizedBox(height: 5), Text(category.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))]))));
          },
        ),
        const SizedBox(height: 24),
        Text('استادکارهای ${city}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 10),
        ...workers.map((worker) => Padding(padding: const EdgeInsets.only(bottom: 10), child: WorkerCard(worker: worker, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkerProfileScreen(worker: worker)))))).toList(),
      ],
    );
  }
}
