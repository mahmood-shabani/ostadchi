import 'package:flutter/material.dart';
import '../../data/models/category.dart';
import '../../data/repositories/mock_repository.dart';
import '../workers/worker_profile_screen.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key, required this.category});
  final ServiceCategory category;

  @override
  Widget build(BuildContext context) {
    final workers = MockRepository.workers.where((w) => _matches(category.name, w)).toList();
    return Scaffold(appBar: AppBar(title: Text(category.name)), body: ListView(padding: const EdgeInsets.all(16), children: [
      Text('تخصص‌ها و استادکاران مرتبط', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      ...workers.map((w) => Card(child: ListTile(title: Text(w.name), subtitle: Text(w.profession), trailing: const Icon(Icons.chevron_left), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkerProfileScreen(worker: w)))))).toList(),
      if (workers.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('هنوز استادکاری در این دسته ثبت نشده است.'))),
    ]));
  }

  bool _matches(String category, dynamic worker) {
    if (category == 'خودرو و موتورسیکلت') return worker.profession.contains('مکانیک');
    if (category == 'ساختمان') return worker.profession.contains('کاشی');
    return false;
  }
}
