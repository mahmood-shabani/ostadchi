import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme/app_theme.dart';
import '../data/services/auth_service.dart';
import '../features/auth/auth_screen.dart';
import '../features/home/home_screen.dart';
import '../features/projects/projects_screen.dart';
import '../features/account/account_screen.dart';

class OstadchiApp extends StatelessWidget {
  const OstadchiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = AuthService(Supabase.instance.client);

    return MaterialApp(
      title: 'استادچی',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: StreamBuilder<AuthState>(
        stream: authService.authStateChanges,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && authService.session == null) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (authService.session == null) return AuthScreen(authService: authService);
          return AppShell(authService: authService);
        },
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.authService});

  final AuthService authService;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  String _city = 'آبادان';

  late final List<Widget> _pages = <Widget>[
    HomeScreen(city: _city),
    const ProjectsScreen(),
    const AccountScreen(),
  ];

  void _changeCity() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('انتخاب شهر')),
            ...['آبادان', 'اهواز', 'خرمشهر', 'تهران'].map(
              (city) => ListTile(
                title: Text(city),
                trailing: city == _city ? const Icon(Icons.check) : null,
                onTap: () => Navigator.pop(context, city),
              ),
            ),
          ],
        ),
      ),
    );

    if (selected == null || selected == _city || !mounted) return;
    setState(() {
      _city = selected;
      _pages[0] = HomeScreen(city: _city);
    });
  }

  Future<void> _signOut() async => widget.authService.signOut();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('استادچی'),
        actions: [
          IconButton(onPressed: _changeCity, icon: const Icon(Icons.location_on_outlined)),
          IconButton(onPressed: _signOut, icon: const Icon(Icons.logout_outlined)),
        ],
      ),
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'پروژه‌ها'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حساب من'),
        ],
      ),
    );
  }
}
