package com.ostadchi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
